<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Student Information Form</title>
</head>
<body>
    <div class="container">
        <h2>Student Information Form</h2>
        <form action="process_data.php" method="post">
            <label for="firstName">First Name:</label>
            <input type="text" id="firstName" name="firstName" required><br>

            <label for="middleName">Middle Name:</label>
            <input type="text" id="middleName" name="middleName" required><br>

            <label for="lastName">Last Name:</label>
            <input type="text" id="lastName" name="lastName" required><br>

            <label for="age">Age (Date of Birth/Age):</label>
            <input type="text" id="age" name="age" required><br>

            <label for="courseYear">Course and Year:</label>
            <input type="text" id="courseYear" name="courseYear" required><br>

            <label for="enrolled">Enrolled:</label>
            <input type="radio" id="enrolledYes" name="enrolled" value="Yes" checked>
            <label for="enrolledYes">Yes</label>
            <input type="radio" id="enrolledNo" name="enrolled" value="No">
            <label for="enrolledNo">No</label><br>

            <label for="subject">Subject:</label>
            <input type="text" id="subject" name="subject" required><br>

            <label for="grade">Grade:</label>
            <input type="number" step="0.1" id="grade" name="grade" required><br>

            <input type="submit" value="Submit">
        </form>
    </div>

    <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $firstName = $_POST["firstName"];
            $middleName = $_POST["middleName"];
            $lastName = $_POST["lastName"];
            $age = $_POST["age"];
            $courseYear = $_POST["courseYear"];
            $enrolled = $_POST["enrolled"];
            $subject = $_POST["subject"];
            $grade = $_POST["grade"];

        // Process the data as needed
        // For example, you can store it in a database or perform other operations.
    }
    ?>


</body>
</html>